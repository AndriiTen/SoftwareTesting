package com.myapp.tests;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

import com.myapp.Triangle;

public class TriangleTest {

    private Triangle triangle = new Triangle();

    // === Tests for valid triangles ===
    
    @Test
    public void shouldReturnEquilateral() {
        int a = 5, b = 5, c = 5;
        String result = triangle.determineTriangleType(a, b, c);
        assertEquals("Equilateral", result);
    }

    @Test
    public void shouldReturnIsosceles() {
        String result = triangle.determineTriangleType(5, 5, 3);
        assertEquals("Isosceles", result);
    }

    @Test
    public void shouldReturnScalene() {
        assertEquals("Scalene", triangle.determineTriangleType(5, 6, 7));
    }

    // === Tests for invalid input ===

    @Test
    public void shouldReturnInvalidSideLength() {
        assertEquals("Invalid side length", triangle.determineTriangleType(0, 5, 5));
        assertEquals("Invalid side length", triangle.determineTriangleType(5, 5, 201));
    }

    // === Tests for not-a-triangle ===

    @Test
    public void shouldReturnNotATriangle() {
        assertEquals("NotATriangle", triangle.determineTriangleType(1, 2, 3));
        assertEquals("NotATriangle", triangle.determineTriangleType(5, 10, 15));
    }
}
